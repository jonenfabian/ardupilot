@echo off
cd /d "%~dp0"
echo ArduCopter SITL (Throw-Mode-Branch) startet...
echo.
echo Mission Planner: Verbindungsart TCP, Host 127.0.0.1, Port 5760
echo Dieses Fenster offen lassen, solange der Simulator laufen soll.
echo.
ArduCopter.elf.exe --model +
pause
